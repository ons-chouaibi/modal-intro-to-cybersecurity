/*
 * mutex.c
 *
 *  Created on: Mar 19, 2016
 *      Author: jiaziyi
 */
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <errno.h>

#define NTHREADS 50
void *increase_counter(void *);


int  counter = 0;
pthread_mutex_t lock=PTHREAD_MUTEX_INITIALIZER ;

int main()
{
	
	pthread_t threads[NTHREADS];
	//create 50 threads of increase_counter, each thread adding 1 to the counter
	for (int j=0;j<NTHREADS;j++){
		if(pthread_create(&threads[j],NULL,*increase_counter,NULL)!=0){
			fprintf(stderr, "Error creating thread\n");
        	return 1;
		}

	}
	for(int j=0;j<NTHREADS;j++){
		pthread_join(threads[j],NULL);
	}

	printf("\nFinal counter value: %d\n", counter);
	pthread_mutex_destroy(&lock);
}

void *increase_counter(void *arg)
{
	
	pthread_mutex_lock(&lock);
	printf("Thread number %ld, working on counter. The current value is %d\n", (long)pthread_self(), counter);
	int i = counter;
	usleep (10000); //simulate the data processing
	counter = i+1;
	pthread_mutex_unlock(&lock);
	
	return NULL;
}
