## Tcp Hijacking challenge
This project implements the **first part** of a TCP hijacking challenge: performing a TCP Reset (RST) attack.

The code listens for TCP traffic on a specified **target port**, and as soon as it detects a connection attempt, it sends multiple **RST packet** back to the client until the connection is forcefully closed.




## Usage:
1. **Compile the program**  compile with make
2. **Run the program as root** sudo ./hack
3. **Input target**
4. **Stop with Ctrl+C** (otherwise the program will continue running)


