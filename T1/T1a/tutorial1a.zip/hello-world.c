#include <stdio.h>
#include <string.h>
#include "hello-world.h"

int main(void){
    print_hello_string();
    return 0;
}

void print_hello_string(){
    printf("hello world\n");
}